import React from 'react'

const CategoriesList = () => {
  return (
    <>
       
    </>
  )
}

export default CategoriesList