export const STATUS = Object.freeze({
    IDLE: 'IDLE',
    FAILED: 'FAILED',
    LOADING: 'LOADING',
    SUCCEEDED: 'SUCCEEDED'
});